package com.huyht.docsach

import android.content.Context
import android.content.SharedPreferences
import android.graphics.Color
import org.json.JSONArray
import org.json.JSONObject

class ReadTheme(val name: String, val bgHex: String, val fgHex: String, val linkHex: String, val dark: Boolean) {
    val bg: Int = Color.parseColor(bgHex)
    val fg: Int = Color.parseColor(fgHex)
}

class ReadFont(val name: String, val css: String)

fun Context.dp(v: Int): Int = (v * resources.displayMetrics.density + 0.5f).toInt()
fun Context.dpf(v: Float): Float = v * resources.displayMetrics.density
fun withAlpha(c: Int, a: Int): Int = (c and 0x00FFFFFF) or (a shl 24)
fun blend(a: Int, b: Int, t: Float): Int {
    val r = (Color.red(a) + (Color.red(b) - Color.red(a)) * t).toInt()
    val g = (Color.green(a) + (Color.green(b) - Color.green(a)) * t).toInt()
    val bl = (Color.blue(a) + (Color.blue(b) - Color.blue(a)) * t).toInt()
    return Color.rgb(r, g, bl)
}

object Settings {
    private lateinit var sp: SharedPreferences

    fun init(c: Context) {
        if (!::sp.isInitialized) sp = c.applicationContext.getSharedPreferences("docsach", Context.MODE_PRIVATE)
    }

    val themes = listOf(
        ReadTheme("Giấy cũ", "#F5ECD7", "#3E3326", "#8A4B08", false),
        ReadTheme("Trắng", "#FFFFFF", "#1C1C1C", "#1565C0", false),
        ReadTheme("Xanh dịu", "#DCEBDD", "#1F2D20", "#2E6B30", false),
        ReadTheme("Tối", "#1E1E1E", "#CFCFCF", "#82B1FF", true),
        ReadTheme("Đen", "#000000", "#A8A8A8", "#82B1FF", true),
        ReadTheme("Chữ trắng nền đen", "#000000", "#FFFFFF", "#82B1FF", true),
        ReadTheme("Chữ vàng nền đen", "#000000", "#E8C27A", "#FFD180", true),
        ReadTheme("Chữ xanh lá nền đen", "#000000", "#7CD992", "#B9F6CA", true),
        ReadTheme("Chữ cam nền đen", "#000000", "#FFA65C", "#FFCC80", true),
        ReadTheme("Nâu tối", "#2B2117", "#D9C7A7", "#E0B07A", true),
        ReadTheme("Xanh đêm", "#0F1B2A", "#C9D6E8", "#90CAF9", true),
        ReadTheme("Xám đậm", "#3A3A3A", "#E6E6E6", "#90CAF9", true),
        ReadTheme("Kem", "#FBF6E9", "#2A2A2A", "#8A4B08", false),
        ReadTheme("Xanh trời nhạt", "#E3EEF7", "#1B2A38", "#1565C0", false),
        ReadTheme("Hồng nhạt", "#F8E8EA", "#3A2427", "#AD1457", false),
        ReadTheme("Xám nhạt", "#E4E4E4", "#1E1E1E", "#1565C0", false),
        ReadTheme("Chữ trắng nền xanh", "#0B3D2E", "#FFFFFF", "#A5D6A7", true)
    )
    val fonts = listOf(
        ReadFont("Có chân", "'Noto Serif', Georgia, serif"),
        ReadFont("Không chân", "Roboto, 'Noto Sans', sans-serif"),
        ReadFont("Theo sách", "")
    )
    val lineHeights = listOf(1.3f, 1.5f, 1.7f, 1.9f)

    var fontSize: Int
        get() = sp.getInt("fs", 19)
        set(v) { sp.edit().putInt("fs", v).apply() }
    var themeIdx: Int
        get() = sp.getInt("theme", 0).coerceIn(0, themes.size - 1)
        set(v) { sp.edit().putInt("theme", v).apply() }
    var fontIdx: Int
        get() = sp.getInt("font", 0).coerceIn(0, fonts.size - 1)
        set(v) { sp.edit().putInt("font", v).apply() }
    var lineIdx: Int
        get() = sp.getInt("line", 2).coerceIn(0, lineHeights.size - 1)
        set(v) { sp.edit().putInt("line", v).apply() }
    var ratio: Float
        get() = sp.getFloat("ratio", 0.5f).coerceIn(0f, 1f)
        set(v) { sp.edit().putFloat("ratio", v).apply() }
    var fullscreen: Boolean
        get() = sp.getBoolean("full", false)
        set(v) { sp.edit().putBoolean("full", v).apply() }
    var keepOn: Boolean
        get() = sp.getBoolean("keepOn", false)
        set(v) { sp.edit().putBoolean("keepOn", v).apply() }

    val theme: ReadTheme get() = themes[themeIdx]

    fun cssJson(): String = JSONObject().apply {
        put("fs", fontSize)
        put("lh", lineHeights[lineIdx].toDouble())
        put("bg", theme.bgHex)
        put("fg", theme.fgHex)
        put("link", theme.linkHex)
        put("font", fonts[fontIdx].css)
        put("hp", 20)
        put("vp", 14)
    }.toString()

    // ---- trạng thái từng ngăn ----
    fun paneMode(i: Int): String = sp.getString("mode$i", "EMPTY") ?: "EMPTY"
    fun setPaneMode(i: Int, m: String) { sp.edit().putString("mode$i", m).apply() }
    fun paneBook(i: Int): String? = sp.getString("book$i", null)
    fun setPaneBook(i: Int, u: String?) { sp.edit().putString("book$i", u).apply() }
    fun notes(i: Int): String = sp.getString("notes$i", "") ?: ""
    fun setNotes(i: Int, s: String) { sp.edit().putString("notes$i", s).apply() }

    // vị trí phím cách (tỉ lệ 0..1 theo ngang/dọc của ngăn)
    fun keyPos(i: Int): Pair<Float, Float> =
        sp.getFloat("keyX$i", 0.5f).coerceIn(0f, 1f) to sp.getFloat("keyY$i", 0.88f).coerceIn(0f, 1f)
    fun setKeyPos(i: Int, x: Float, y: Float) {
        sp.edit().putFloat("keyX$i", x.coerceIn(0f, 1f)).putFloat("keyY$i", y.coerceIn(0f, 1f)).apply()
    }

    // ---- vị trí đọc từng sách ----
    fun savePos(id: String, ch: Int, frac: Float, pct: Int) {
        sp.edit().putString("pos_$id", "$ch;$frac").putInt("pct_$id", pct).apply()
    }

    fun getPos(id: String): Pair<Int, Float> {
        val s = sp.getString("pos_$id", null) ?: return 0 to 0f
        val a = s.split(';')
        val ch = a.getOrNull(0)?.toIntOrNull() ?: 0
        val f = a.getOrNull(1)?.toFloatOrNull() ?: 0f
        return ch to (if (f.isNaN()) 0f else f.coerceIn(0f, 1f))
    }

    fun percent(id: String): Int = sp.getInt("pct_$id", 0)

    // ---- sách đọc gần đây ----
    fun recent(): List<Pair<String, String>> {
        val arr = try { JSONArray(sp.getString("recent", "[]")) } catch (e: Exception) { JSONArray() }
        val out = ArrayList<Pair<String, String>>()
        for (i in 0 until arr.length()) {
            val o = arr.optJSONObject(i) ?: continue
            out.add(o.optString("u") to o.optString("t"))
        }
        return out
    }

    fun addRecent(u: String, t: String) {
        val l = recent().filter { it.first != u }.toMutableList()
        l.add(0, u to t)
        saveRecent(l.take(20))
    }

    fun removeRecent(u: String) = saveRecent(recent().filter { it.first != u })

    private fun saveRecent(l: List<Pair<String, String>>) {
        val arr = JSONArray()
        l.forEach { arr.put(JSONObject().put("u", it.first).put("t", it.second)) }
        sp.edit().putString("recent", arr.toString()).apply()
    }
}
