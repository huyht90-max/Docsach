package com.huyht.docsach

import android.annotation.SuppressLint
import android.app.Activity
import android.content.Intent
import android.graphics.drawable.GradientDrawable
import android.os.Build
import android.os.Bundle
import android.view.Gravity
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.View
import android.view.ViewGroup
import android.view.WindowInsets
import android.view.WindowInsetsController
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.Toast
import kotlin.math.abs
import kotlin.math.roundToInt

class MainActivity : Activity() {

    private lateinit var container: LinearLayout
    private lateinit var divider: FrameLayout
    private lateinit var pill: View
    lateinit var top: ReaderPane
    lateinit var bottom: ReaderPane
    private var active: ReaderPane? = null
    private var dividerH = 0

    @SuppressLint("ClickableViewAccessibility")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        Settings.init(this)

        dividerH = dp(22)
        container = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        top = ReaderPane(this, 0)
        bottom = ReaderPane(this, 1)

        // Thanh chia giữa 2 ngăn — kéo lên/xuống để đổi chiều cao
        divider = FrameLayout(this)
        pill = View(this)
        divider.addView(pill, FrameLayout.LayoutParams(dp(56), dp(5), Gravity.CENTER))

        container.addView(top, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0))
        container.addView(divider, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, dividerH))
        container.addView(bottom, LinearLayout.LayoutParams(ViewGroup.LayoutParams.MATCH_PARENT, 0, 1f))
        setContentView(container)

        container.addOnLayoutChangeListener { _, _, t, _, b, _, ot, _, ob ->
            if (b - t != ob - ot) container.post { applyRatio() }
        }
        divider.setOnTouchListener(DividerTouch())

        applyAll()
        top.restore()
        bottom.restore()
        handleIntent(intent)
    }

    override fun onNewIntent(intent: Intent) {
        super.onNewIntent(intent)
        handleIntent(intent)
    }

    private fun handleIntent(i: Intent?) {
        if (i?.action == Intent.ACTION_VIEW) {
            i.data?.let { top.openBook(it.toString()) }
        }
    }

    // ================================================================ chia ngăn

    private fun avail() = (container.height - dividerH).coerceAtLeast(0)

    private fun setTopHeight(h: Int) {
        val lp = top.layoutParams as LinearLayout.LayoutParams
        if (lp.height != h) {
            lp.height = h
            top.layoutParams = lp
        }
    }

    private fun applyRatio() {
        if (container.height <= 0) return
        setTopHeight((Settings.ratio * avail()).roundToInt())
    }

    private fun cyclePreset() {
        val presets = listOf(0.5f, 1f, 0f)
        val i = presets.indexOfFirst { abs(it - Settings.ratio) < 0.02f }
        Settings.ratio = presets[(i + 1) % presets.size]
        applyRatio()
    }

    private inner class DividerTouch : View.OnTouchListener {
        var downY = 0f
        var startH = 0
        var moved = false
        var lastTap = 0L

        override fun onTouch(v: View, e: MotionEvent): Boolean {
            val a = avail()
            when (e.actionMasked) {
                MotionEvent.ACTION_DOWN -> {
                    downY = e.rawY
                    startH = top.height
                    moved = false
                    pill.alpha = 1f
                }
                MotionEvent.ACTION_MOVE -> {
                    val dy = e.rawY - downY
                    if (abs(dy) > dp(4)) moved = true
                    if (moved) setTopHeight((startH + dy).toInt().coerceIn(0, a))
                }
                MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> {
                    pill.alpha = 0.6f
                    if (moved) {
                        var h = top.layoutParams.height.coerceIn(0, a)
                        if (h < dp(60)) h = 0                    // hít về mép
                        if (h > a - dp(60)) h = a
                        setTopHeight(h)
                        if (a > 0) Settings.ratio = h.toFloat() / a
                    } else if (e.actionMasked == MotionEvent.ACTION_UP) {
                        val now = System.currentTimeMillis()
                        if (now - lastTap < 350) { cyclePreset(); lastTap = 0L } else lastTap = now
                    }
                }
            }
            return true
        }
    }

    // ================================================================ cài đặt chung

    fun applyAll() {
        val t = Settings.theme
        container.setBackgroundColor(t.bg)
        divider.setBackgroundColor(blend(t.bg, t.fg, 0.10f))
        pill.background = GradientDrawable().apply {
            cornerRadius = dpf(3f)
            setColor(withAlpha(t.fg, 0x80))
        }
        pill.alpha = 0.6f
        top.applyTheme()
        bottom.applyTheme()
        applyWindow()
    }

    @Suppress("DEPRECATION")
    private fun applyWindow() {
        val t = Settings.theme
        window.statusBarColor = t.bg
        window.navigationBarColor = t.bg
        if (Settings.keepOn) window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        else window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        if (Build.VERSION.SDK_INT >= 30) {
            val c = window.insetsController ?: return
            val light = WindowInsetsController.APPEARANCE_LIGHT_STATUS_BARS or
                WindowInsetsController.APPEARANCE_LIGHT_NAVIGATION_BARS
            c.setSystemBarsAppearance(if (t.dark) 0 else light, light)
            if (Settings.fullscreen) {
                c.hide(WindowInsets.Type.systemBars())
                c.systemBarsBehavior = WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
            } else {
                c.show(WindowInsets.Type.systemBars())
            }
        } else {
            var f = 0
            if (!t.dark) f = f or View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR or View.SYSTEM_UI_FLAG_LIGHT_NAVIGATION_BAR
            if (Settings.fullscreen) f = f or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
            window.decorView.systemUiVisibility = f
        }
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) {
        super.onWindowFocusChanged(hasFocus)
        if (hasFocus && Settings.fullscreen) applyWindow()
    }

    fun changeFont(d: Int) {
        Settings.fontSize = (Settings.fontSize + d).coerceIn(12, 40)
        applyAll()
    }

    fun cycleTheme() {
        Settings.themeIdx = (Settings.themeIdx + 1) % Settings.themes.size
        applyAll()
        toast("Nền: ${Settings.theme.name}")
    }

    fun cycleFont() {
        Settings.fontIdx = (Settings.fontIdx + 1) % Settings.fonts.size
        applyAll()
        toast("Phông: ${Settings.fonts[Settings.fontIdx].name}")
    }

    fun cycleLine() {
        Settings.lineIdx = (Settings.lineIdx + 1) % Settings.lineHeights.size
        applyAll()
        toast("Giãn dòng: ${Settings.lineHeights[Settings.lineIdx]}")
    }

    fun toggleFullscreen() {
        Settings.fullscreen = !Settings.fullscreen
        applyWindow()
    }

    fun toggleKeepOn() {
        Settings.keepOn = !Settings.keepOn
        applyWindow()
        toast(if (Settings.keepOn) "Luôn sáng màn hình: BẬT" else "Luôn sáng màn hình: TẮT")
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // ================================================================ mở tệp

    fun pickFile(pane: ReaderPane) {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply {
            addCategory(Intent.CATEGORY_OPENABLE)
            type = "*/*"
        }
        try {
            startActivityForResult(i, 100 + pane.idx)
        } catch (e: Exception) {
            toast("Không mở được trình chọn tệp")
        }
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (resultCode != RESULT_OK) return
        val uri = data?.data ?: return
        try {
            contentResolver.takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION)
        } catch (_: Exception) { }
        when (requestCode) {
            100 -> top.openBook(uri.toString())
            101 -> bottom.openBook(uri.toString())
        }
    }

    // ================================================================ phím & chạm

    override fun dispatchTouchEvent(ev: MotionEvent): Boolean {
        if (ev.actionMasked == MotionEvent.ACTION_DOWN) {
            val loc = IntArray(2)
            bottom.getLocationOnScreen(loc)
            active = if (ev.rawY >= loc[1]) bottom else top
        }
        return super.dispatchTouchEvent(ev)
    }

    private fun readingPane(): ReaderPane? {
        val a = active
        if (a != null && a.mode == ReaderPane.Mode.BOOK && a.height > 0) return a
        return listOf(top, bottom).firstOrNull { it.mode == ReaderPane.Mode.BOOK && it.height > 0 }
    }

    // Phím âm lượng để lật trang ngăn đang đọc
    override fun onKeyDown(keyCode: Int, event: KeyEvent): Boolean {
        if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) {
            val p = readingPane()
            if (p != null) {
                if (keyCode == KeyEvent.KEYCODE_VOLUME_DOWN) p.next() else p.prev()
                return true
            }
        }
        return super.onKeyDown(keyCode, event)
    }

    override fun onKeyUp(keyCode: Int, event: KeyEvent): Boolean {
        if ((keyCode == KeyEvent.KEYCODE_VOLUME_DOWN || keyCode == KeyEvent.KEYCODE_VOLUME_UP) && readingPane() != null) return true
        return super.onKeyUp(keyCode, event)
    }

    @Deprecated("Deprecated in Java")
    override fun onBackPressed() {
        if (top.hideMenu() or bottom.hideMenu()) return
        @Suppress("DEPRECATION")
        super.onBackPressed()
    }
}
