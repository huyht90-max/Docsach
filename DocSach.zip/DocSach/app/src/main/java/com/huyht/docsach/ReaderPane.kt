package com.huyht.docsach

import android.annotation.SuppressLint
import android.app.AlertDialog
import android.content.Context
import android.content.Intent
import android.graphics.Color
import android.graphics.drawable.Drawable
import android.graphics.drawable.GradientDrawable
import android.graphics.drawable.LayerDrawable
import android.graphics.drawable.StateListDrawable
import android.net.Uri
import android.text.Editable
import android.text.TextUtils
import android.text.TextWatcher
import android.view.Gravity
import android.view.HapticFeedbackConstants
import android.view.View
import android.view.ViewGroup
import android.view.inputmethod.InputMethodManager
import android.webkit.JavascriptInterface
import android.webkit.WebResourceRequest
import android.webkit.WebView
import android.webkit.WebViewClient
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.HorizontalScrollView
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.TextView
import android.widget.Toast
import org.json.JSONObject
import java.io.File

private const val MP = ViewGroup.LayoutParams.MATCH_PARENT
private const val WC = ViewGroup.LayoutParams.WRAP_CONTENT

/** Một ngăn (trên hoặc dưới). Có thể là: sách, ghi chú, trống, hoặc màn hình chọn sách. */
@SuppressLint("SetJavaScriptEnabled", "ViewConstructor")
class ReaderPane(private val act: MainActivity, val idx: Int) : FrameLayout(act) {

    enum class Mode { EMPTY, BOOK, NOTES, BLANK }

    var mode = Mode.EMPTY
        private set
    var book: Book? = null
        private set

    private var chapter = 0
    private var page = 0
    private var count = 1
    private var pendingWhere: String? = null
    private var loadToken = 0
    private var chapterToken = 0

    private val web = WebView(act)
    private val status = TextView(act)
    private val emptyScroll = ScrollView(act)
    private val emptyBox = LinearLayout(act)
    private val notes = EditText(act)
    private val blank = View(act)
    private val spaceKey = TextView(act)
    private val menuScroll = HorizontalScrollView(act)
    private val menuRow = LinearLayout(act)
    private val moreBtn = TextView(act)
    private val menuPills = ArrayList<TextView>()

    init {
        val statusH = act.dp(20)
        val pad = act.dp(20)

        // ---- WebView hiển thị sách
        web.settings.apply {
            javaScriptEnabled = true
            allowFileAccess = true
            blockNetworkLoads = true
            setSupportZoom(false)
            builtInZoomControls = false
            displayZoomControls = false
            textZoom = 100
        }
        web.isVerticalScrollBarEnabled = false
        web.isHorizontalScrollBarEnabled = false
        web.overScrollMode = View.OVER_SCROLL_NEVER
        web.addJavascriptInterface(Bridge(), "Bridge")
        web.webViewClient = object : WebViewClient() {
            override fun onPageFinished(view: WebView?, url: String?) {
                if (url != null) onLoaded(url)
            }
            override fun shouldOverrideUrlLoading(view: WebView?, request: WebResourceRequest?): Boolean {
                val u = request?.url ?: return true
                return handleLink(u)
            }
        }
        addView(web, LayoutParams(MP, MP).apply { bottomMargin = statusH })

        // ---- dòng trạng thái (chương · trang · %)
        status.textSize = 11f
        status.gravity = Gravity.CENTER
        status.maxLines = 1
        status.ellipsize = TextUtils.TruncateAt.MIDDLE
        status.setPadding(act.dp(12), 0, act.dp(12), 0)
        status.setOnClickListener { if (mode == Mode.BOOK) toggleMenu() }
        addView(status, LayoutParams(MP, statusH, Gravity.BOTTOM))

        // ---- màn hình chọn sách
        emptyBox.orientation = LinearLayout.VERTICAL
        emptyBox.setPadding(pad, pad, pad, pad)
        emptyScroll.addView(emptyBox, LayoutParams(MP, WC))
        addView(emptyScroll, LayoutParams(MP, MP))

        // ---- ghi chú
        notes.gravity = Gravity.TOP or Gravity.START
        notes.background = null
        notes.textSize = 17f
        notes.hint = "Ghi chú…"
        notes.setPadding(pad, act.dp(44), pad, pad)
        notes.setText(Settings.notes(idx))
        notes.addTextChangedListener(object : TextWatcher {
            override fun afterTextChanged(s: Editable?) { Settings.setNotes(idx, s?.toString() ?: "") }
            override fun beforeTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
            override fun onTextChanged(s: CharSequence?, a: Int, b: Int, c: Int) {}
        })
        addView(notes, LayoutParams(MP, MP))

        // ---- để trống
        blank.setBackgroundColor(Color.BLACK)
        addView(blank, LayoutParams(MP, MP))

        // ---- phím cách kiểu BlackBerry: bấm = lật trang ngăn kia, nhấn giữ = trang trước
        spaceKey.text = "␣"
        spaceKey.textSize = 18f
        spaceKey.gravity = Gravity.CENTER
        spaceKey.setTextColor(0x55FFFFFF)
        spaceKey.background = StateListDrawable().apply {
            addState(intArrayOf(android.R.attr.state_pressed), keyDrawable(true))
            addState(intArrayOf(), keyDrawable(false))
        }
        spaceKey.isClickable = true
        spaceKey.setOnClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.KEYBOARD_TAP)
            act.turnOther(this, 1)
        }
        spaceKey.setOnLongClickListener {
            it.performHapticFeedback(HapticFeedbackConstants.LONG_PRESS)
            act.turnOther(this, -1)
            true
        }
        addView(spaceKey, LayoutParams(MP, act.dp(60), Gravity.BOTTOM or Gravity.CENTER_HORIZONTAL).apply {
            leftMargin = act.dp(40)
            rightMargin = act.dp(40)
            bottomMargin = act.dp(36)
        })

        // ---- thanh menu (hiện khi chạm giữa trang)
        menuRow.orientation = LinearLayout.HORIZONTAL
        menuRow.setPadding(act.dp(8), act.dp(8), act.dp(8), act.dp(8))
        menuScroll.isHorizontalScrollBarEnabled = false
        menuScroll.addView(menuRow)
        menuScroll.visibility = GONE
        addView(menuScroll, LayoutParams(MP, WC, Gravity.TOP))
        addMenu("Mục lục", true) { showToc() }
        addMenu("Đi tới %", true) { showGoto() }
        addMenu("A−") { act.changeFont(-1) }
        addMenu("A+") { act.changeFont(1) }
        addMenu("Màu nền & chữ", true) { act.pickTheme() }
        addMenu("Phông") { act.cycleFont() }
        addMenu("Giãn dòng") { act.cycleLine() }
        addMenu("Toàn màn hình") { act.toggleFullscreen() }
        addMenu("Giữ màn hình sáng") { act.toggleKeepOn() }
        addMenu("Mở sách khác", true) { act.pickFile(this) }
        addMenu("Ngăn này…", true) { chooseMode() }

        // ---- nút ⋯ cho chế độ ghi chú / trống
        moreBtn.text = "⋯"
        moreBtn.textSize = 24f
        moreBtn.setPadding(act.dp(16), act.dp(2), act.dp(16), act.dp(6))
        moreBtn.setOnClickListener { chooseMode() }
        addView(moreBtn, LayoutParams(WC, WC, Gravity.TOP or Gravity.END))

        setMode(Mode.EMPTY, save = false)
        applyTheme()
    }

    // ================================================================ giao diện

    private fun pill(text: String, onClick: () -> Unit): TextView = TextView(act).apply {
        this.text = text
        textSize = 14f
        gravity = Gravity.CENTER
        setPadding(act.dp(14), act.dp(9), act.dp(14), act.dp(9))
        isClickable = true
        setOnClickListener { onClick() }
        stylePill(this)
    }

    /** Hình phím cách BlackBerry: dài, bo góc, đen bóng, viền xám, có vệt sáng phía trên */
    private fun keyDrawable(pressed: Boolean): Drawable {
        val r = act.dpf(14f)
        val rim = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(0xFF8A8A8A.toInt(), 0xFF3C3C3C.toInt())
        ).apply { cornerRadius = r }
        val face = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            if (pressed) intArrayOf(0xFF555555.toInt(), 0xFF2E2E2E.toInt())
            else intArrayOf(0xFF353535.toInt(), 0xFF0C0C0C.toInt())
        ).apply { cornerRadius = r - act.dpf(1.5f) }
        val gloss = GradientDrawable(
            GradientDrawable.Orientation.TOP_BOTTOM,
            intArrayOf(if (pressed) 0x18FFFFFF else 0x30FFFFFF, 0x00FFFFFF)
        ).apply { cornerRadius = r - act.dpf(3f) }
        return LayerDrawable(arrayOf(rim, face, gloss)).apply {
            val b = act.dp(2)
            setLayerInset(1, b, b, b, b)
            setLayerInset(2, act.dp(4), act.dp(3), act.dp(4), act.dp(30))
        }
    }

    private fun stylePill(p: TextView) {
        val t = Settings.theme
        p.setTextColor(t.fg)
        p.background = GradientDrawable().apply {
            cornerRadius = act.dpf(20f)
            setStroke(act.dp(1), withAlpha(t.fg, 0x40))
            setColor(withAlpha(t.fg, 0x0D))
        }
    }

    private fun addMenu(text: String, hide: Boolean = false, onClick: () -> Unit) {
        val p = pill(text) {
            if (hide) menuScroll.visibility = GONE
            onClick()
        }
        menuPills.add(p)
        menuRow.addView(p, LinearLayout.LayoutParams(WC, WC).apply { marginEnd = act.dp(6) })
    }

    fun applyTheme() {
        val t = Settings.theme
        setBackgroundColor(t.bg)
        web.setBackgroundColor(t.bg)
        status.setTextColor(withAlpha(t.fg, 0x99))
        notes.setTextColor(t.fg)
        notes.setHintTextColor(withAlpha(t.fg, 0x66))
        menuScroll.setBackgroundColor(withAlpha(t.bg, 0xF4))
        moreBtn.setTextColor(if (mode == Mode.BLANK) 0xFF666666.toInt() else withAlpha(t.fg, 0x99))
        menuPills.forEach { stylePill(it) }
        if (mode == Mode.EMPTY) buildEmpty()
        if (mode == Mode.BOOK) web.evaluateJavascript("window.R&&R.restyle(${Settings.cssJson()})", null)
    }

    private fun buildEmpty() {
        emptyBox.removeAllViews()
        val t = Settings.theme
        fun label(s: String, size: Float, alpha: Int) = TextView(act).apply {
            text = s
            textSize = size
            setTextColor(withAlpha(t.fg, alpha))
            setPadding(0, act.dp(6), 0, act.dp(10))
        }
        fun lp() = LinearLayout.LayoutParams(MP, WC).apply { bottomMargin = act.dp(8) }

        emptyBox.addView(label(if (idx == 0) "Ngăn trên" else "Ngăn dưới", 20f, 0xE0))
        emptyBox.addView(label(
            "Kéo thanh ngang giữa 2 ngăn để đổi chiều cao. Chạm đúp vào thanh để chuyển nhanh: nửa màn hình → toàn bộ trên → toàn bộ dưới.",
            13f, 0x99))
        emptyBox.addView(pill("Mở sách (EPUB, TXT)") { act.pickFile(this) }, lp())
        emptyBox.addView(pill("Ghi chú") { setMode(Mode.NOTES) }, lp())
        emptyBox.addView(pill("Để trống (nền đen)") { setMode(Mode.BLANK) }, lp())

        val rec = Settings.recent()
        if (rec.isNotEmpty()) {
            emptyBox.addView(label("Đọc gần đây  (nhấn giữ để xóa khỏi danh sách)", 13f, 0x99).apply {
                setPadding(0, act.dp(16), 0, act.dp(8))
            })
            for ((u, title) in rec) {
                val pct = Settings.percent(BookLoader.idOf(u))
                val p = pill("$title   ·   $pct%") { openBook(u) }
                p.gravity = Gravity.START or Gravity.CENTER_VERTICAL
                p.setOnLongClickListener {
                    AlertDialog.Builder(act).setMessage("Xóa \"$title\" khỏi danh sách?")
                        .setPositiveButton("Xóa") { _, _ ->
                            Settings.removeRecent(u)
                            File(act.filesDir, "books/${BookLoader.idOf(u)}").deleteRecursively()
                            buildEmpty()
                        }
                        .setNegativeButton("Thôi", null).show()
                    true
                }
                emptyBox.addView(p, lp())
            }
        }
    }

    fun setMode(m: Mode, save: Boolean = true) {
        if (mode == Mode.NOTES && m != Mode.NOTES) hideKeyboard()
        mode = m
        if (save) Settings.setPaneMode(idx, m.name)
        web.visibility = if (m == Mode.BOOK) VISIBLE else GONE
        status.visibility = if (m == Mode.BOOK) VISIBLE else GONE
        emptyScroll.visibility = if (m == Mode.EMPTY) VISIBLE else GONE
        notes.visibility = if (m == Mode.NOTES) VISIBLE else GONE
        blank.visibility = if (m == Mode.BLANK) VISIBLE else GONE
        spaceKey.visibility = if (m == Mode.BLANK) VISIBLE else GONE
        moreBtn.visibility = if (m == Mode.NOTES || m == Mode.BLANK) VISIBLE else GONE
        moreBtn.setTextColor(if (m == Mode.BLANK) 0xFF666666.toInt() else withAlpha(Settings.theme.fg, 0x99))
        menuScroll.visibility = GONE
        if (m != Mode.BOOK) {
            loadToken++
            book = null
            pendingWhere = null
            if (save) Settings.setPaneBook(idx, null)
            web.loadUrl("about:blank")
        }
        if (m == Mode.EMPTY) buildEmpty()
        moreBtn.bringToFront()
    }

    private fun hideKeyboard() {
        val imm = act.getSystemService(Context.INPUT_METHOD_SERVICE) as InputMethodManager
        imm.hideSoftInputFromWindow(windowToken, 0)
        notes.clearFocus()
    }

    fun toggleMenu() {
        if (menuScroll.visibility == VISIBLE) {
            menuScroll.visibility = GONE
        } else {
            menuScroll.visibility = VISIBLE
            menuScroll.bringToFront()
        }
    }

    fun hideMenu(): Boolean {
        if (menuScroll.visibility == VISIBLE) { menuScroll.visibility = GONE; return true }
        return false
    }

    fun chooseMode() {
        menuScroll.visibility = GONE
        val opts = arrayOf("Mở sách từ máy…", "Danh sách sách gần đây", "Ghi chú", "Để trống (nền đen)")
        AlertDialog.Builder(act)
            .setTitle(if (idx == 0) "Ngăn trên" else "Ngăn dưới")
            .setItems(opts) { _, i ->
                when (i) {
                    0 -> act.pickFile(this@ReaderPane)
                    1 -> setMode(Mode.EMPTY)
                    2 -> setMode(Mode.NOTES)
                    3 -> setMode(Mode.BLANK)
                }
            }.show()
    }

    // ================================================================ sách

    fun restore() {
        when (Settings.paneMode(idx)) {
            "BOOK" -> {
                val u = Settings.paneBook(idx)
                if (u != null) openBook(u) else setMode(Mode.EMPTY)
            }
            "NOTES" -> setMode(Mode.NOTES)
            "BLANK" -> setMode(Mode.BLANK)
            else -> setMode(Mode.EMPTY)
        }
    }

    fun openBook(uri: String) {
        setMode(Mode.BOOK)
        web.alpha = 0f
        status.text = "Đang mở sách…"
        val token = ++loadToken
        Thread {
            val res = runCatching { BookLoader.load(act, uri) }
            post {
                if (token != loadToken) return@post
                res.onSuccess { showBook(it) }.onFailure {
                    Toast.makeText(act, "Không mở được: ${it.message}", Toast.LENGTH_LONG).show()
                    setMode(Mode.EMPTY)
                }
            }
        }.start()
    }

    private fun showBook(b: Book) {
        book = b
        Settings.setPaneBook(idx, b.uri)
        Settings.addRecent(b.uri, b.title)
        val (ch, frac) = Settings.getPos(b.id)
        loadChapter(ch, "{frac:$frac}")
    }

    private fun loadChapter(ch: Int, where: String) {
        val b = book ?: return
        chapter = ch.coerceIn(0, b.chapters.size - 1)
        pendingWhere = where
        web.alpha = 0f
        val tok = ++chapterToken
        postDelayed({ if (tok == chapterToken) web.alpha = 1f }, 2500)
        web.loadUrl(Uri.fromFile(b.chapters[chapter]).toString())
    }

    private fun onLoaded(url: String) {
        val w = pendingWhere ?: return
        if (!url.startsWith("file:")) return
        pendingWhere = null
        web.evaluateJavascript(readerJs(act) + "\n;R.setup(" + Settings.cssJson() + "," + w + ");", null)
    }

    private fun handleLink(u: Uri): Boolean {
        val b = book ?: return true
        when (u.scheme) {
            "file" -> {
                val path = u.path ?: return true
                val i = b.indexOf(File(path))
                val frag = u.fragment
                if (i == chapter && frag != null) {
                    web.evaluateJavascript("window.R&&R.anchor(${JSONObject.quote(frag)})", null)
                } else if (i >= 0) {
                    loadChapter(i, if (frag != null) "{anchor:${JSONObject.quote(frag)}}" else "{frac:0}")
                }
            }
            "http", "https", "mailto" -> try {
                act.startActivity(Intent(Intent.ACTION_VIEW, u))
            } catch (_: Exception) { }
        }
        return true
    }

    fun next() { if (mode == Mode.BOOK) web.evaluateJavascript("window.R&&R.next()", null) }
    fun prev() { if (mode == Mode.BOOK) web.evaluateJavascript("window.R&&R.prev()", null) }

    private fun progressPct(): Int {
        val b = book ?: return 0
        val f = (chapter + (page + 1f) / count.coerceAtLeast(1)) / b.chapters.size
        return (f * 100).toInt().coerceIn(0, 100)
    }

    private fun savePos() {
        val b = book ?: return
        val frac = if (count > 0) page.toFloat() / count else 0f
        Settings.savePos(b.id, chapter, frac, progressPct())
    }

    private fun updateStatus() {
        val b = book ?: return
        val chTitle = b.toc.lastOrNull { it.chapter <= chapter }?.title ?: b.title
        status.text = "$chTitle   ·   ${page + 1}/$count   ·   ${progressPct()}%"
    }

    private fun showToc() {
        val b = book ?: return
        val items = b.toc
        if (items.isEmpty()) return
        val names = items.map { "      ".repeat(it.depth.coerceIn(0, 4)) + it.title }.toTypedArray()
        val d = AlertDialog.Builder(act)
            .setTitle(b.title)
            .setItems(names) { _, i ->
                val t = items[i]
                loadChapter(t.chapter, if (t.anchor != null) "{anchor:${JSONObject.quote(t.anchor)}}" else "{frac:0}")
            }
            .setNegativeButton("Đóng", null)
            .show()
        val cur = items.indexOfLast { it.chapter <= chapter }
        if (cur > 0) d.listView?.setSelection(cur)
    }

    private fun showGoto() {
        val b = book ?: return
        val n = b.chapters.size
        val cur = ((chapter + page.toFloat() / count.coerceAtLeast(1)) / n * 1000).toInt().coerceIn(0, 1000)
        val box = LinearLayout(act).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(act.dp(24), act.dp(16), act.dp(24), 0)
        }
        val lbl = TextView(act).apply { textSize = 16f }
        val sb = SeekBar(act).apply { max = 1000; progress = cur }
        fun upd(p: Int) { lbl.text = "${p / 10}.${p % 10}%" }
        upd(cur)
        sb.setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar?, p: Int, fromUser: Boolean) = upd(p)
            override fun onStartTrackingTouch(s: SeekBar?) {}
            override fun onStopTrackingTouch(s: SeekBar?) {}
        })
        box.addView(lbl)
        box.addView(sb, LinearLayout.LayoutParams(MP, WC))
        AlertDialog.Builder(act)
            .setTitle("Đi tới vị trí")
            .setView(box)
            .setPositiveButton("Đi") { _, _ ->
                val pos = sb.progress / 1000f * n
                val ch = pos.toInt().coerceIn(0, n - 1)
                loadChapter(ch, "{frac:${(pos - ch).coerceIn(0f, 0.999f)}}")
            }
            .setNegativeButton("Hủy", null)
            .show()
    }

    /** Cầu nối JS → Kotlin */
    inner class Bridge {
        @JavascriptInterface
        fun onReady() { post { web.alpha = 1f } }

        @JavascriptInterface
        fun onPage(p: Int, c: Int) {
            post {
                page = p
                count = c.coerceAtLeast(1)
                savePos()
                updateStatus()
            }
        }

        @JavascriptInterface
        fun onEdge(dir: Int) {
            post {
                val b = book ?: return@post
                if (dir > 0) {
                    if (chapter < b.chapters.size - 1) loadChapter(chapter + 1, "{frac:0}")
                    else Toast.makeText(act, "Đã hết sách", Toast.LENGTH_SHORT).show()
                } else if (chapter > 0) {
                    loadChapter(chapter - 1, "{end:true}")
                }
            }
        }

        @JavascriptInterface
        fun onMenu() { post { toggleMenu() } }
    }

    companion object {
        private var js: String? = null
        fun readerJs(c: Context): String =
            js ?: c.assets.open("reader.js").bufferedReader().use { it.readText() }.also { js = it }
    }
}
