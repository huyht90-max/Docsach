package com.huyht.docsach

import android.content.Context
import android.net.Uri
import android.provider.OpenableColumns
import android.util.Xml
import org.json.JSONArray
import org.json.JSONObject
import org.xmlpull.v1.XmlPullParser
import java.io.File
import java.io.FileOutputStream
import java.io.StringReader
import java.nio.ByteBuffer
import java.nio.charset.CharacterCodingException
import java.nio.charset.Charset
import java.nio.charset.CodingErrorAction
import java.security.MessageDigest
import java.util.zip.ZipFile

class TocItem(val title: String, val chapter: Int, val anchor: String?, val depth: Int)

class Book(
    val id: String,
    val uri: String,
    val title: String,
    val dir: File,
    val chapters: List<File>,
    val toc: List<TocItem>
) {
    private val paths = chapters.map { it.canonicalPath }
    fun indexOf(f: File): Int = paths.indexOf(f.canonicalPath)
}

/** Đọc EPUB / TXT, giải nén vào bộ nhớ app, trả về danh sách chương. */
object BookLoader {

    fun idOf(uri: String): String {
        val d = MessageDigest.getInstance("MD5").digest(uri.toByteArray())
        return d.joinToString("") { "%02x".format(it) }
    }

    fun load(ctx: Context, uriStr: String): Book {
        val id = idOf(uriStr)
        val dir = File(ctx.filesDir, "books/$id")
        val meta = File(dir, "meta.json")
        if (meta.exists()) {
            try { return readMeta(id, uriStr, dir, meta) } catch (_: Exception) { }
        }
        dir.deleteRecursively()
        dir.mkdirs()
        try {
            val uri = Uri.parse(uriStr)
            val name = displayName(ctx, uri) ?: "Sách"
            val low = name.lowercase()
            if (low.endsWith(".pdf") || low.endsWith(".mobi") || low.endsWith(".azw3") || low.endsWith(".azw")) {
                throw Exception("Chưa hỗ trợ định dạng này, hãy dùng EPUB hoặc TXT")
            }
            val isEpub = low.endsWith(".epub") || (!low.endsWith(".txt") && looksLikeZip(ctx, uri))
            val book = if (isEpub) loadEpub(ctx, uri, id, uriStr, dir, name) else loadTxt(ctx, uri, id, uriStr, dir, name)
            writeMeta(book, meta)
            return book
        } catch (e: Exception) {
            dir.deleteRecursively()
            throw e
        }
    }

    // ------------------------------------------------------------------ meta

    private fun writeMeta(b: Book, f: File) {
        val o = JSONObject()
        o.put("title", b.title)
        val ch = JSONArray()
        val base = b.dir.canonicalPath + File.separator
        b.chapters.forEach { ch.put(it.canonicalPath.removePrefix(base)) }
        o.put("chapters", ch)
        val toc = JSONArray()
        b.toc.forEach {
            toc.put(JSONObject().put("t", it.title).put("c", it.chapter).put("a", it.anchor ?: "").put("d", it.depth))
        }
        o.put("toc", toc)
        f.writeText(o.toString())
    }

    private fun readMeta(id: String, uri: String, dir: File, f: File): Book {
        val o = JSONObject(f.readText())
        val chA = o.getJSONArray("chapters")
        val chapters = (0 until chA.length()).map { File(dir, chA.getString(it)) }
        if (chapters.isEmpty() || !chapters[0].exists()) throw Exception("meta hỏng")
        val tA = o.getJSONArray("toc")
        val toc = (0 until tA.length()).map {
            val t = tA.getJSONObject(it)
            TocItem(t.getString("t"), t.getInt("c"), t.optString("a").ifEmpty { null }, t.optInt("d"))
        }
        return Book(id, uri, o.getString("title"), dir, chapters, toc)
    }

    // ------------------------------------------------------------------ helpers

    private fun displayName(ctx: Context, uri: Uri): String? {
        try {
            ctx.contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
                if (c.moveToFirst()) return c.getString(0)
            }
        } catch (_: Exception) { }
        return uri.lastPathSegment?.substringAfterLast('/')
    }

    private fun looksLikeZip(ctx: Context, uri: Uri): Boolean = try {
        ctx.contentResolver.openInputStream(uri)?.use { s ->
            val b = ByteArray(2); s.read(b) == 2 && b[0] == 'P'.code.toByte() && b[1] == 'K'.code.toByte()
        } ?: false
    } catch (_: Exception) { false }

    private fun stripExt(n: String) = n.substringBeforeLast('.', n)

    private fun htmlDecode(s: String): String {
        var r = s.replace(Regex("<[^>]+>"), "")
        r = r.replace(Regex("&#(x?)([0-9a-fA-F]+);")) {
            val hex = it.groupValues[1].isNotEmpty()
            val code = it.groupValues[2].toIntOrNull(if (hex) 16 else 10)
            if (code != null) String(Character.toChars(code)) else it.value
        }
        return r.replace("&nbsp;", " ").replace("&lt;", "<").replace("&gt;", ">")
            .replace("&quot;", "\"").replace("&apos;", "'").replace("&#39;", "'").replace("&amp;", "&")
            .replace(Regex("\\s+"), " ").trim()
    }

    private fun esc(s: String) = s.replace("&", "&amp;").replace("<", "&lt;").replace(">", "&gt;")

    // ------------------------------------------------------------------ EPUB

    private fun loadEpub(ctx: Context, uri: Uri, id: String, uriStr: String, dir: File, name: String): Book {
        // chép ra file tạm rồi mở bằng ZipFile (chịu được nhiều kiểu nén hơn ZipInputStream)
        val tmp = File(dir, "__src.epub")
        (ctx.contentResolver.openInputStream(uri) ?: throw Exception("Không đọc được tệp")).use { i ->
            FileOutputStream(tmp).use { o -> i.copyTo(o) }
        }
        val root = dir.canonicalPath + File.separator
        ZipFile(tmp).use { z ->
            val en = z.entries()
            while (en.hasMoreElements()) {
                val e = en.nextElement()
                val out = File(dir, e.name)
                if (!out.canonicalPath.startsWith(root)) continue
                if (e.isDirectory) { out.mkdirs(); continue }
                out.parentFile?.mkdirs()
                z.getInputStream(e).use { i -> FileOutputStream(out).use { o -> i.copyTo(o) } }
            }
        }
        tmp.delete()

        val container = File(dir, "META-INF/container.xml")
        val opfRel = if (container.exists())
            Regex("full-path\\s*=\\s*[\"']([^\"']+)[\"']").find(container.readText())?.groupValues?.get(1)
        else null
        val opf = opfRel?.let { File(dir, it) }?.takeIf { it.exists() }
            ?: dir.walkTopDown().firstOrNull { it.isFile && it.name.endsWith(".opf", true) }
            ?: throw Exception("EPUB không hợp lệ (thiếu .opf)")
        val opfDir = opf.parentFile!!

        class Item(val href: String, val media: String, val props: String)
        val manifest = HashMap<String, Item>()
        val spine = ArrayList<String>()
        var ncxId: String? = null
        var title: String? = null

        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(StringReader(opf.readText()))
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            if (ev == XmlPullParser.START_TAG) {
                when (p.name.substringAfter(':')) {
                    "item" -> {
                        val iid = p.getAttributeValue(null, "id")
                        val href = p.getAttributeValue(null, "href")
                        if (iid != null && href != null) manifest[iid] = Item(
                            href,
                            p.getAttributeValue(null, "media-type") ?: "",
                            p.getAttributeValue(null, "properties") ?: ""
                        )
                    }
                    "itemref" -> p.getAttributeValue(null, "idref")?.let { spine.add(it) }
                    "spine" -> ncxId = p.getAttributeValue(null, "toc")
                    "title" -> if (title == null) {
                        title = try { p.nextText().trim() } catch (_: Exception) { null }
                    }
                }
            }
            ev = p.next()
        }

        fun resolve(base: File, href: String): File =
            File(base, Uri.decode(href.substringBefore('#'))).canonicalFile

        val chapters = spine.mapNotNull { manifest[it] }
            .filter { it.media.contains("html") || it.href.contains(Regex("\\.x?html?$", RegexOption.IGNORE_CASE)) }
            .map { resolve(opfDir, it.href) }
            .filter { it.exists() }
            .distinctBy { it.path }
        if (chapters.isEmpty()) throw Exception("EPUB không có nội dung đọc được")

        val paths = chapters.map { it.canonicalPath }
        fun entry(base: File, href: String, label: String, depth: Int): TocItem? {
            if (label.isBlank()) return null
            val idx = paths.indexOf(resolve(base, href).canonicalPath)
            if (idx < 0) return null
            val a = href.substringAfter('#', "").ifEmpty { null }
            return TocItem(label, idx, a, depth)
        }

        var toc: List<TocItem> = emptyList()
        val nav = manifest.values.firstOrNull { it.props.split(' ').contains("nav") }
        if (nav != null) toc = try {
            val f = resolve(opfDir, nav.href)
            parseNav(f.readText()).mapNotNull { entry(f.parentFile!!, it.first, it.second, it.third) }
        } catch (_: Exception) { emptyList() }
        if (toc.isEmpty()) {
            val ncx = ncxId?.let { manifest[it] } ?: manifest.values.firstOrNull { it.media == "application/x-dtbncx+xml" }
            if (ncx != null) toc = try {
                val f = resolve(opfDir, ncx.href)
                parseNcx(f.readText()).mapNotNull { entry(f.parentFile!!, it.first, it.second, it.third) }
            } catch (_: Exception) { emptyList() }
        }
        if (toc.isEmpty()) toc = chapters.indices.map { TocItem("Phần ${it + 1}", it, null, 0) }

        val t = title?.takeIf { it.isNotBlank() } ?: stripExt(name)
        return Book(id, uriStr, t, dir, chapters, toc)
    }

    /** EPUB3 nav.xhtml → (href, nhãn, cấp) */
    private fun parseNav(text: String): List<Triple<String, String, Int>> {
        val navRe = Regex("<nav\\b[^>]*epub:type\\s*=\\s*[\"'][^\"']*\\btoc\\b[^\"']*[\"'][^>]*>(.*?)</nav>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        val body = navRe.find(text)?.groupValues?.get(1)
            ?: Regex("<nav\\b[^>]*>(.*?)</nav>", setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
                .find(text)?.groupValues?.get(1) ?: return emptyList()
        val tok = Regex("<ol\\b|</ol>|<a\\b[^>]*?href\\s*=\\s*[\"']([^\"']*)[\"'][^>]*>(.*?)</a>",
            setOf(RegexOption.IGNORE_CASE, RegexOption.DOT_MATCHES_ALL))
        var depth = 0
        val out = ArrayList<Triple<String, String, Int>>()
        for (m in tok.findAll(body)) {
            val v = m.value.lowercase()
            when {
                v.startsWith("<ol") -> depth++
                v.startsWith("</ol") -> depth--
                else -> out.add(Triple(m.groupValues[1], htmlDecode(m.groupValues[2]), (depth - 1).coerceAtLeast(0)))
            }
        }
        return out
    }

    /** EPUB2 toc.ncx → (href, nhãn, cấp) */
    private fun parseNcx(text: String): List<Triple<String, String, Int>> {
        val out = ArrayList<Triple<String, String, Int>>()
        val p = Xml.newPullParser()
        p.setFeature(XmlPullParser.FEATURE_PROCESS_NAMESPACES, false)
        p.setInput(StringReader(text))
        var inMap = false
        var depth = 0
        var label = ""
        var ev = p.eventType
        while (ev != XmlPullParser.END_DOCUMENT) {
            val n = p.name?.substringAfter(':')
            if (ev == XmlPullParser.START_TAG) {
                when (n) {
                    "navMap" -> inMap = true
                    "navPoint" -> if (inMap) { depth++; label = "" }
                    "text" -> if (inMap) label = try { p.nextText() } catch (_: Exception) { "" }
                    "content" -> if (inMap) {
                        val src = p.getAttributeValue(null, "src")
                        if (src != null) out.add(Triple(src, htmlDecode(label), (depth - 1).coerceAtLeast(0)))
                    }
                }
            } else if (ev == XmlPullParser.END_TAG) {
                when (n) {
                    "navMap" -> inMap = false
                    "navPoint" -> if (inMap) depth--
                }
            }
            ev = p.next()
        }
        return out
    }

    // ------------------------------------------------------------------ TXT

    private fun decodeText(b: ByteArray): String {
        if (b.size >= 3 && b[0] == 0xEF.toByte() && b[1] == 0xBB.toByte() && b[2] == 0xBF.toByte())
            return String(b, 3, b.size - 3, Charsets.UTF_8)
        if (b.size >= 2 && b[0] == 0xFF.toByte() && b[1] == 0xFE.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16LE)
        if (b.size >= 2 && b[0] == 0xFE.toByte() && b[1] == 0xFF.toByte())
            return String(b, 2, b.size - 2, Charsets.UTF_16BE)
        return try {
            Charsets.UTF_8.newDecoder()
                .onMalformedInput(CodingErrorAction.REPORT)
                .onUnmappableCharacter(CodingErrorAction.REPORT)
                .decode(ByteBuffer.wrap(b)).toString()
        } catch (_: CharacterCodingException) {
            val cs = listOf("windows-1258", "windows-1252")
                .firstOrNull { try { Charset.isSupported(it) } catch (_: Exception) { false } } ?: "ISO-8859-1"
            String(b, Charset.forName(cs))
        }
    }

    private fun loadTxt(ctx: Context, uri: Uri, id: String, uriStr: String, dir: File, name: String): Book {
        val bytes = (ctx.contentResolver.openInputStream(uri) ?: throw Exception("Không đọc được tệp")).use { it.readBytes() }
        val lines = decodeText(bytes).replace("\r\n", "\n").replace('\r', '\n').split('\n')
        val heading = Regex(
            "^(chương|chuong|chapter|hồi|hoi|phần|phan|quyển|quyen|tập|tap|part)\\s+[0-9ivxlcdm]+\\b.*",
            RegexOption.IGNORE_CASE
        )

        val chapters = ArrayList<File>()
        val toc = ArrayList<TocItem>()
        val sb = StringBuilder()
        var hasText = false

        fun flush() {
            if (!hasText) return
            val f = File(dir, "c%04d.html".format(chapters.size))
            f.writeText(
                "<!DOCTYPE html><html><head><meta charset=\"utf-8\">" +
                    "<style>p{margin:0 0 .55em;text-indent:1.4em}h2{text-align:center;margin:.6em 0 1em;text-indent:0}</style>" +
                    "</head><body>$sb</body></html>"
            )
            chapters.add(f)
            sb.setLength(0)
            hasText = false
        }

        for (raw in lines) {
            val line = raw.trim()
            if (line.isEmpty()) continue
            if (line.length < 100 && heading.matches(line)) {
                flush()
                toc.add(TocItem(line, chapters.size, null, 0))
                sb.append("<h2>").append(esc(line)).append("</h2>")
                hasText = true
                continue
            }
            sb.append("<p>").append(esc(line)).append("</p>")
            hasText = true
            if (sb.length > 80_000) flush()   // chương quá dài thì cắt bớt cho nhẹ
        }
        flush()
        if (chapters.isEmpty()) throw Exception("Tệp rỗng")
        val finalToc = if (toc.isEmpty()) chapters.indices.map { TocItem("Phần ${it + 1}", it, null, 0) } else toc
        return Book(id, uriStr, stripExt(name), dir, chapters, finalToc)
    }
}
