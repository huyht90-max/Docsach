// Bộ phân trang kiểu Kindle: dàn chữ thành các cột rộng bằng màn hình,
// mỗi cột là 1 trang; lật trang = cuộn ngang đúng 1 bề rộng.
(function () {
  if (window.R) return;
  var B = window.Bridge;
  var st = document.createElement('style');
  (document.head || document.documentElement).appendChild(st);

  var W = 1, page = 0, count = 1, ready = false;

  function css(o) {
    var I = ' !important;';
    var hp = o.hp, vp = o.vp;
    var s = '';
    s += 'html{margin:0' + I + 'padding:0' + I + 'height:100%' + I + 'overflow:hidden' + I +
      'background:' + o.bg + I + '-webkit-text-size-adjust:none' + I + '}';
    s += 'body{margin:0' + I + 'padding:' + vp + 'px ' + hp + 'px' + I + 'box-sizing:border-box' + I +
      'width:auto' + I + 'max-width:none' + I + 'min-height:0' + I + 'height:100vh' + I + 'max-height:none' + I +
      'overflow:visible' + I +
      '-webkit-column-width:calc(100vw - ' + (2 * hp) + 'px)' + I + 'column-width:calc(100vw - ' + (2 * hp) + 'px)' + I +
      '-webkit-column-gap:' + (2 * hp) + 'px' + I + 'column-gap:' + (2 * hp) + 'px' + I + 'column-fill:auto' + I +
      'background:' + o.bg + I + 'color:' + o.fg + I + 'font-size:' + o.fs + 'px' + I +
      'line-height:' + o.lh + I + (o.font ? 'font-family:' + o.font + I : '') +
      'text-align:justify;overflow-wrap:break-word;-webkit-hyphens:auto;hyphens:auto}';
    s += 'body *{color:inherit' + I + 'background-color:transparent' + I + 'max-width:100%' + I + '}';
    s += 'p,li,dd,dt,blockquote,div,span,td,th{line-height:' + o.lh + I + '}';
    if (o.font) s += 'p,div,span,li,td,th,h1,h2,h3,h4,h5,h6,a,em,strong,i,b{font-family:' + o.font + I + '}';
    s += 'a{color:' + o.link + I + '}';
    s += 'img,svg,video,image{max-width:100%' + I + 'max-height:calc(100vh - ' + (2 * vp) + 'px)' + I +
      'object-fit:contain;break-inside:avoid;-webkit-column-break-inside:avoid}';
    s += 'img{height:auto' + I + '}';
    s += 'pre{white-space:pre-wrap' + I + '}';
    return s;
  }

  function se() { return document.scrollingElement || document.documentElement; }

  function measure() {
    W = window.innerWidth || document.documentElement.clientWidth || 1;
    var sw = Math.max(se().scrollWidth, document.body ? document.body.scrollWidth : 0);
    count = Math.max(1, Math.round(sw / W));
  }

  function clamp(p) { return Math.max(0, Math.min(count - 1, p)); }

  // Dịch cả body sang trái thay vì cuộn (cuộn bị giới hạn ở trang cuối)
  function show() {
    if (document.body) document.body.style.setProperty('transform', 'translateX(' + (-page * W) + 'px)', 'important');
    window.scrollTo(0, 0);
    B.onPage(page, count);
  }

  function anchorPage(a) {
    var el = document.getElementById(a) || document.getElementsByName(a)[0];
    if (!el) return 0;
    var r = el.getBoundingClientRect();
    return clamp(Math.floor((r.left + page * W + 1) / W));
  }

  function relayoutTo(f) {
    measure();
    page = clamp(Math.round(f * count));
    show();
  }

  window.R = {
    setup: function (o, where) {
      st.textContent = css(o);
      setTimeout(function () {
        measure();
        if (where.end) page = count - 1;
        else if (where.anchor) page = anchorPage(where.anchor);
        else page = clamp(Math.round((where.frac || 0) * count));
        ready = true;
        show();
        B.onReady();
      }, 30);
    },
    restyle: function (o) {
      var f = page / count;
      st.textContent = css(o);
      if (ready) relayoutTo(f);
    },
    next: function () {
      if (!ready) return;
      if (page < count - 1) { page++; show(); } else B.onEdge(1);
    },
    prev: function () {
      if (!ready) return;
      if (page > 0) { page--; show(); } else B.onEdge(-1);
    },
    anchor: function (a) { if (ready) { page = anchorPage(a); show(); } }
  };

  // Đổi chiều cao ngăn => dàn trang lại, giữ nguyên vị trí đang đọc
  var rt = null;
  window.addEventListener('resize', function () {
    if (!ready) return;
    var f = page / count;
    clearTimeout(rt);
    rt = setTimeout(function () {
      if (window.innerHeight < 40) return;   // ngăn đang thu nhỏ hết, bỏ qua
      relayoutTo(f);
    }, 120);
  });

  // Chạm trái = trang trước, chạm phải = trang sau, giữa = menu; vuốt ngang để lật
  var sx = 0, sy = 0, t0 = 0;
  document.addEventListener('touchstart', function (e) {
    var t = e.touches[0]; sx = t.clientX; sy = t.clientY; t0 = Date.now();
  }, { passive: true });

  document.addEventListener('touchend', function (e) {
    var t = e.changedTouches[0];
    var dx = t.clientX - sx, dy = t.clientY - sy, dt = Date.now() - t0;
    if (Math.abs(dx) > 50 && Math.abs(dx) > Math.abs(dy) * 1.2) {
      e.preventDefault();
      if (dx < 0) R.next(); else R.prev();
      return;
    }
    if (dt > 450 || Math.abs(dx) > 12 || Math.abs(dy) > 12) return;  // nhấn giữ = chọn chữ
    var a = e.target && e.target.closest ? e.target.closest('a[href]') : null;
    if (a) return;                                                     // để link chạy
    var sel = window.getSelection();
    if (sel && !sel.isCollapsed) { sel.removeAllRanges(); e.preventDefault(); return; }
    e.preventDefault();
    var x = t.clientX / W;
    if (x < 0.3) R.prev(); else if (x > 0.7) R.next(); else B.onMenu();
  }, { passive: false });
})();
