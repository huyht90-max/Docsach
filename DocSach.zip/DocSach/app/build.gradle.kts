plugins {
    id("com.android.application")
    id("org.jetbrains.kotlin.android")
}

// Số build do GitHub Actions truyền vào (-Pvc=...), tăng dần mỗi lần build
// => bản mới luôn cài đè được lên bản cũ.
val vc = (project.findProperty("vc") as String?)?.toIntOrNull() ?: 1

android {
    namespace = "com.huyht.docsach"
    compileSdk = 34

    defaultConfig {
        applicationId = "com.huyht.docsach"
        minSdk = 26
        targetSdk = 34
        versionCode = vc
        versionName = "1.0.$vc"
    }

    // Khóa ký cố định đi kèm project => mọi bản build có cùng chữ ký,
    // cài đè không cần gỡ app.
    signingConfigs {
        create("app") {
            storeFile = file("docsach.p12")
            storeType = "pkcs12"
            storePassword = "docsach123"
            keyAlias = "docsach"
            keyPassword = "docsach123"
        }
    }

    buildTypes {
        release {
            isMinifyEnabled = false
            signingConfig = signingConfigs.getByName("app")
        }
        debug {
            signingConfig = signingConfigs.getByName("app")
        }
    }

    compileOptions {
        sourceCompatibility = JavaVersion.VERSION_17
        targetCompatibility = JavaVersion.VERSION_17
    }
    kotlinOptions {
        jvmTarget = "17"
    }
}
