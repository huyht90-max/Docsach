# Đọc Sách — app đọc EPUB/TXT kiểu Kindle, chia 2 ngăn trên/dưới

## Build bằng GitHub (từ điện thoại)
1. Tạo repo mới trên GitHub.
2. Upload file `DocSach.zip` (giữ nguyên, không giải nén) vào thư mục gốc repo.
3. Tạo file `.github/workflows/build.yml` (Add file → Create new file, gõ đúng đường dẫn đó) và dán nội dung file `build.yml` đi kèm.
4. Vào tab **Actions** chờ build xong (~4–6 phút) → tab **Releases** sẽ có `DocSach-vN.apk` để tải và cài.
5. Lần sau sửa code: chỉ cần upload đè `DocSach.zip`, workflow tự build bản mới, cài đè lên bản cũ được (cùng chữ ký, số phiên bản tự tăng).

## Cách dùng
- **Thanh ngang giữa 2 ngăn**: kéo lên/xuống để đổi chiều cao. Kéo sát mép sẽ hít hẳn về mép (1 ngăn chiếm toàn màn hình).
- **Chạm đúp thanh ngang**: chuyển nhanh ½ – toàn bộ trên – toàn bộ dưới.
- Mỗi ngăn có thể là: **sách**, **ghi chú**, hoặc **để trống (nền đen)**. Hai ngăn có thể đọc 2 sách khác nhau.
- Trong sách: chạm **phải** = trang sau, chạm **trái** = trang trước, vuốt ngang để lật, chạm **giữa** = menu (mục lục, đi tới %, cỡ chữ, nền, phông, giãn dòng, toàn màn hình, giữ sáng).
- **Phím âm lượng** lật trang ngăn vừa chạm.
- Ngăn **để trống** có phím cách kiểu BlackBerry: bấm = sang trang mới ở ngăn sách, nhấn giữ = trang trước.
- Menu **Màu nền & chữ**: 18 kiểu (chữ trắng nền đen, chữ vàng/xanh/cam nền đen, giấy cũ, kem, xanh đêm…).
- Tự nhớ vị trí đọc từng cuốn, nhớ chiều cao ngăn.
- Định dạng: EPUB (2 và 3), TXT (UTF-8; tự tách chương theo dòng "Chương 1…", "Chapter 1…").
